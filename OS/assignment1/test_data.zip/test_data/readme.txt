More detials can be found in websubmission.
And do not need print output_details.txt on your code.